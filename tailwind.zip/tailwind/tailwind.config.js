/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{html,js}'],
  theme: {
    container: {
      center: true,
      padding: '1rem'
    },
    extend: {
      screens: {
        'sp' : '320px',
        'mp' : '375px',
        'lp' : '425px',
        'll' : '1440px',
        'xll': '1600px',
      },
      colors: {
        transparent: 'transparent',
        current: 'currentColor',
        'samuel': '#eaeaea',
        'dave': '#ededed'
      },
    },
  },
  plugins: [],
}
